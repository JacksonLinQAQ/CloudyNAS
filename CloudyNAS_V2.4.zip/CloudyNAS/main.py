from flask import Flask, render_template, redirect, request, url_for, send_file
import shutil
import datetime
import socket
import os
import json
import random

app = Flask(__name__)

# 不支持的檔案名
unsupportedSymbols = ['&', '?', '#', '%']

# 主頁

@app.route('/index.html', methods=['GET'])
def index():
    # 取得URL的參數值
    # print(request.args.get('a'))
    return render_template("index.html", isAdmin=request.remote_addr == socket.gethostbyname(socket.gethostname()))

@app.route('/')
def index2():
    return redirect('/index.html')

# 管理員設置

@app.route('/admin.html')
def admin():
    if request.remote_addr == socket.gethostbyname(socket.gethostname()):
        # 取得所有現有的用戶
        users = os.listdir('.cloudy/users')
        for i, user in enumerate(users):
            with open(f'.cloudy/users/{user}/user.json', 'r') as f:
                users[i] = [user, json.load(f)['id']]

        # 取得前端指定需要進行修改的用戶
        user = request.args.get('user')

        # 取得顯示提示的文字
        alertTexts = request.args.get('alert')

        # 如果提示的文字爲空值
        if not alertTexts:
            alertTexts = ""

        # 取得前端是否需要修改用戶名/密碼或添加用戶
        changeUsername = request.args.get('changeUsername')
        if changeUsername == '1':
            changeUsername = True
        else:
            changeUsername = False
        changePassword = request.args.get('changePassword')
        if changePassword == '1':
            changePassword = True
        else:
            changePassword = False
        addUser = request.args.get('addUser')
        if addUser == '1':
            addUser = True
        else:
            addUser = False
        
        return render_template('admin.html', users=users, user=user, changeUsername=changeUsername, changePassword=changePassword, addUser=addUser, alertTexts=alertTexts)
    else:
        return "你沒有權限訪問此頁面"

@app.route('/change-username', methods=['POST'])
def changeusername():
    if request.remote_addr == socket.gethostbyname(socket.gethostname()):
        # 取得前端提供的原用戶名和新用戶名
        user = request.args.get('user')
        newname = request.form['username']

        # 顯示提示的文字設爲空字符串
        alert = ""

        # 將不允許的用戶名稱狀態設爲False
        unsupportedUsername = False

        # 如果新用戶名不爲空值，就修改用戶名及相關資料
        if newname:
            if os.path.exists(f".cloudy/users/{user}/user.json"):
                if not os.path.exists(f".cloudy/users/{newname}"):
                    if ' ' not in newname:
                        for symbol in unsupportedSymbols:
                            if symbol in user:
                                unsupportedUsername = True
                                print(f"Username cannot contain {symbol}")
                                alert = f"不允許的用戶名稱"
                    
                        if not unsupportedUsername:
                            with open(f".cloudy/users/{user}/user.json", 'r') as f:
                                config = json.load(f)
                            config['username'] = newname
                            with open(f".cloudy/users/{user}/user.json", 'w') as f:
                                json.dump(config, f)

                            os.rename(f".cloudy/users/{user}", f".cloudy/users/{newname}")
                            print(f"User: {user} changed username to {newname} successfully")

                    else:
                        print(f"Username cannot contain space")
                        alert = "用戶名稱不能包含空格"

                else:
                    print(f"User: {newname} already exists")
                    alert = f"用戶：{newname}已存在"

        return redirect(f'/admin.html?alert={alert}')
    
    else:
        return "你沒有權限訪問此頁面"

@app.route('/change-password', methods=['POST'])
def changepassword():
    if request.remote_addr == socket.gethostbyname(socket.gethostname()):
        # 取得前端提供的用戶名和新密碼
        user = request.args.get('user')
        newpw = request.form['password']

        # 如果新密碼不爲空值，就修改密碼及相關資料
        if newpw:
            if os.path.exists(f".cloudy/users/{user}/user.json"):
                with open(f".cloudy/users/{user}/user.json", 'r') as f:
                    config = json.load(f)
                config['password'] = newpw
                with open(f".cloudy/users/{user}/user.json", 'w') as f:
                    json.dump(config, f)

                print(f"User: {user} changed password successfully")

        return redirect('/admin.html')
    
    else:
        return "你沒有權限訪問此頁面"

@app.route('/delete-user')
def deleteuser():
    if request.remote_addr == socket.gethostbyname(socket.gethostname()):
        # 取得前端提供的用戶名
        user = request.args.get('user')

        # 刪除用戶
        shutil.rmtree(f'.cloudy/users/{user}')
        print(f"User: {user} deleted successfully")

        return redirect('/admin.html')
    else:
        return "你沒有權限訪問此頁面"

@app.route('/add-user', methods=['POST'])
def adduser():
    if request.remote_addr == socket.gethostbyname(socket.gethostname()):
        # 取得前端提供的新用戶名和密碼
        user = request.form['username']
        pw = request.form['password']

        # 顯示提示的文字設爲空字符串
        alert = ""

        # 將不允許的用戶名稱狀態設爲False
        unsupportedUsername = False

        # 如果用戶名和密碼不爲空值，就新增用戶
        if user and pw:
            if not os.path.exists(f".cloudy/users/{user}"):
                if ' ' not in user:
                    for symbol in unsupportedSymbols:
                        if symbol in user:
                            unsupportedUsername = True
                            print(f"Username cannot contain {symbol}")
                            alert = f"不允許的用戶名稱"
                    
                    if not unsupportedUsername:
                        os.makedirs(f".cloudy/users/{user}")
                        with open(f".cloudy/users/{user}/user.json", 'w') as f:
                            id = str(random.randint(111111111111111, 999999999999999))
                            json.dump({'username':user, 'password':pw, 'id':id}, f)
                        print(f"User: ({user}) created successfully")
                else:
                    unsupportedUsername = True
                    print(f"Username cannot contain space")
                    alert = "用戶名稱不能包含空格"
            else:
                print(f"User: ({user}) already exists")
                alert = f"用戶：{user}已存在"

        return redirect(f'/admin.html?alert={alert}')
    
    else:
        return "你沒有權限訪問此頁面"

# 登入

@app.route('/login.html', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("login.html")

    else:
        # 取得前端提供的用戶名與密碼
        username = request.form['login-form-username']
        password = request.form['login-form-password']

        # 如果該用戶存在
        if username in os.listdir('.cloudy/users'):
            with open('.cloudy/users/{}/user.json'.format(username), 'r') as f:
                user_info = json.load(f)
            
            # 如果密碼匹配
            if password == user_info["password"]:
                return redirect(f'/storage.html?user={user_info["username"]}&id={user_info["id"]}')

            else:
                return render_template('login_fail.html')
        
        else:
            return render_template('login_fail.html')

# 個人空間

@app.route('/storage.html')
def mystorage():
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')
    # 取得顯示提示的文字
    alertTexts = request.args.get('alert')
    # 取得前端指定需要進行修改的文件
    file = request.args.get('file')
    # 取得前端是否需要重命名文件
    renameFile = request.args.get('renameFile')
    if renameFile == '1':
        renameFile = True
    else:
        renameFile = False

    # 如果提示的文字爲空值
    if not alertTexts:
        alertTexts = ""

    # 如果該用戶存在
    if user in os.listdir('.cloudy/users'):
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        if user_info['id'] == id:
            # 取得所有個人空間的文件
            files:list = os.listdir(f'.cloudy/users/{user}')
            del files[files.index('user.json')]

            # 判斷設備類型，並根據設備類型返回對應頁面
            agent = request.headers.get('User-Agent')
            if 'iphone' in agent.lower() or 'android' in agent.lower() or 'blackberry' in agent.lower():
                return render_template('storage_mobile.html', user=user, id=id, files=files, os=os, alertTexts=alertTexts, file=file, renameFile=renameFile)
            else:
                return render_template('storage.html', user=user, id=id, files=files, os=os, alertTexts=alertTexts, file=file, renameFile=renameFile)

        else:
            return render_template('login_fail.html')
    else:
        return render_template('login_fail.html')

@app.route('/rename-file/<filename>', methods=['POST'])
def renamefile(filename):
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 顯示提示的文字設爲空字符串
    alert = ""

    # 如果用戶名不為空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            renamedFilename = request.form['rename']
            file_path = f".cloudy/users/{user}/{filename}"
            file_path_public = f".cloudy/public/{filename}"
            renamed_file_path = f".cloudy/users/{user}/{renamedFilename}"
            renamed_file_path_public = f".cloudy/public/{renamedFilename}"

            # 如果文件存在且重命名後的文件名
            if os.path.exists(file_path):
                if not os.path.exists(f'.cloudy/users/{user}/{renamedFilename}') and not os.path.exists(f'.cloudy/public/{renamedFilename}'):
                    os.rename(file_path, renamed_file_path)
                    
                    # 如果文件存在於公共空間内
                    if os.path.exists(file_path_public):
                        os.rename(file_path_public, renamed_file_path_public)
                        print(f"File: {filename} changed file name to {renamedFilename} successfully")

                else:
                    print(f"File: {renamedFilename} already exists")
                    alert = "文件已存在"

            return redirect(f"/storage.html?user={user}&id={id}&alert={alert}")
        else:
            return render_template('login_fail.html')
    else:
        return render_template('login_fail.html')

# 公共空間

@app.route('/public.html')
def public():
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果用戶名不為空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            # 取得所有公共空間的文件
            files:list = os.listdir(f'.cloudy/public')
            
            # 判斷設備類型，並根據設備類型返回對應頁面
            agent = request.headers.get('User-Agent')
            if 'iphone' in agent.lower() or 'android' in agent.lower() or 'blackberry' in agent.lower():
                return render_template('public_mobile.html', files=files, user=user, id=id)
            else:
                return render_template('public.html', files=files, user=user, id=id)

        else:
            return render_template('login_fail.html')

# 下載文件

@app.route('/download/<file>')
def download(file):
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果用戶名不為空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)
        
        # 如果ID匹配
        if user_info['id'] == id:

            # 返回對應文件
            downloads = f'.cloudy/users/{user}/{file}'
            if os.path.exists(downloads):
                return send_file(downloads, as_attachment=True)
            else:
                return send_file("templates/_blank.txt", as_attachment=True)   
        else:
            return send_file("templates/_blank.txt", as_attachment=True)
    else:
        return send_file("templates/_blank.txt", as_attachment=True)

@app.route('/download-public/<file>')
def downloadpublic(file):
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果用戶名不為空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)
        
        # 如果ID匹配
        if user_info['id'] == id:

            # 返回對應文件
            download = f'.cloudy/public/{file}'
            if os.path.exists(download):
                return send_file(download, as_attachment=True)
            else:
                return send_file("templates/_blank.txt", as_attachment=True)

# 上傳文件

@app.route('/upload.html', methods=['GET', 'POST'])
def upload():
    global unsupportedSymbols

    if request.method == 'GET':
        # 取得前端提供的用戶名與ID
        user = request.args.get('user')
        id = request.args.get('id')
        return render_template('upload.html', user=user, id=id, unsupportedSymbols=unsupportedSymbols)
    else:
        # 取得前端提供的用戶名與ID
        user = request.args.get('user')
        id = request.args.get('id')
        # 顯示提示的文字設爲空字符串
        alert = ""

        # 如果有上傳文件
        if request.files and request.files.getlist("file-upload")[0].filename:
            # 如果用戶名不爲空值
            if user:
                with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
                    user_info = json.load(f)

                # 如果ID匹配
                if id == user_info['id']:
                    # 取得上傳的所有文件
                    files = request.files.getlist("file-upload")
                    for file in files:
                        unsupportedFileName = False

                        # 檢查文件名是否有不允許的字符
                        for symbol in unsupportedSymbols:
                            if symbol in file.filename:
                                unsupportedFileName = True
                                alert = f"不允許的文件名"

                        # 如果文件名沒有不允許的字符
                        if not unsupportedFileName:

                            # 判斷文件是否已存在
                            if not os.path.exists(f'.cloudy/users/{user}/{file.filename}') and not os.path.exists(f'.cloudy/public/{file.filename}'):
                                # 如果文件不存在

                                # 保存文件
                                file.save(f'.cloudy/users/{user}/{file.filename}')
                                print(f"File: '{file.filename.split('/')[-1]}' save successfully")
                            else:
                                # 如果文件已存在就在文件名結尾加上'(2)'
                                name = file.filename

                                while os.path.exists(f'.cloudy/users/{user}/{name}') or os.path.exists(f'.cloudy/public/{name}'):
                                    # 把檔案名與副檔名分開
                                    name = name[::-1].split('.', 1)
                                    
                                    name[-1] = ')2(' + name[-1]
                                    
                                    # 合并文件名
                                    name = (f"{''.join(name)}")
                                    name = name[::-1]
                                
                                # 保存文件
                                file.save(f'.cloudy/users/{user}/{name}')
                                print(f"File: '{name}' save successfully")
                                alert = f"因個人空間或公共空間存在同名文件，因此已將你上傳的文件名稱修改為“{name}”"
                            
                            # 關閉文件
                            file.close()
                        else:
                            print(f"File: '{file.filename.split('/')[-1]}' file name unsupported")

        return redirect('/storage.html?user={}&id={}&alert={}'.format(user, id, alert))

# 刪除文件

@app.route('/delete/<file>')
def delete(file):
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果用戶名不爲空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            delete = f'.cloudy/users/{user}/{file}'
            delete_public = f'.cloudy/public/{file}'

            # 如果文件存在於個人空間
            if os.path.exists(delete) and os.path.isfile(delete):
                os.remove(delete)
                print(f"File: '{delete.split('/')[-1]}' deleted successfully")

            # 如果文件存在於公共空間
            if os.path.exists(delete_public) and os.path.isfile(delete_public):
                os.remove(delete_public)
                print(f"File: '{delete.split('/')[-1]}' removed from public successfully")

        return redirect(f'/storage.html?user={user_info["username"]}&id={user_info["id"]}')

# 在公共空間中添加或移除文件

@app.route('/add-to-public/<file>')
def addtopublic(file):
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果用戶名不爲空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            path = f'.cloudy/users/{user}/{file}'

            # 如果文件存在
            if os.path.exists(path) and os.path.isfile(path):
                with open(path, 'rb') as f:
                    bytesFile = f.read()

                with open(f'.cloudy/public/{file}', 'wb') as f:
                    f.write(bytesFile)

            return redirect(f'/storage.html?user={user_info["username"]}&id={user_info["id"]}')

@app.route('/remove-from-public/<file>')
def removefrompublic(file):
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果用戶名不爲空值
    if user:
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            path = f'.cloudy/public/{file}'

            if os.path.exists(path) and os.path.isfile(path):
                os.remove(path)

            return redirect(f'/storage.html?user={user_info["username"]}&id={user_info["id"]}')

# API

@app.route('/api-get-files-from-user')
def api_getfilesfromuser():
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果該用戶存在
    if user in os.listdir('.cloudy/users'):
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            files:list = os.listdir(f'.cloudy/users/{user}')
            del files[files.index('user.json')]

            return files
        else:
            return render_template('login_fail.html')
    else:
        return render_template('login_fail.html')

@app.route('/api-get-files-from-public')
def api_getfilesfrompublic():
    # 取得前端提供的用戶名與ID
    user = request.args.get('user')
    id = request.args.get('id')

    # 如果該用戶存在
    if user in os.listdir('.cloudy/users'):
        with open('.cloudy/users/{}/user.json'.format(user), 'r') as f:
            user_info = json.load(f)

        # 如果ID匹配
        if user_info['id'] == id:
            files:list = os.listdir(f'.cloudy/public')

            return files
        else:
            return render_template('login_fail.html')
    else:
        return render_template('login_fail.html')

# 頁面不存在

@app.errorhandler(404)
def notFound(e):
    return render_template("404.html"), 404

# 服務器運行

if __name__ == "__main__":
    app.run(socket.gethostbyname(socket.gethostname()), 8080, debug=False)